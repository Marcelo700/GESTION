<?php
const BASE_URL = "http://localhost/gestion/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "eventos";
const CHARSET = "charset=utf8";
?>